
fetch("box.json")
    .then(function(response){
        return response.json()
    })
    .then(function(data){
        appendData(data)
    })
    .catch(function(err){
        console.log("Error: " + err)
    })

function appendData(data){
    var contain = document.getElementById("data-json");
    var button = document.getElementById("for-button");
    for (var i=0; i < data.length; i++) {
        var div = document.createElement("div");
        //var div2 = document.createElement("div");
        //var picture = document.createElement("div");

        div.innerHTML = "<div class='container'>" + "Name: " + data[i].firstname + " " + data[i].lastname + "<br>" + "<br>" + 
                        "<img src='" + data[i].picture + "' class='picture'>"+ "<br>" + "<br>" + "<a class='btn' href='" + "#?="+ 
                        data[i].id + "'>Button "+ data[i].id +"</a>" + "</div>";

        //div2.innerHTML = "<a href='" + "#?="+ data[i].id + "'>Button "+ data[i].id +"</a>";
        
        contain.appendChild(div)
        //button.appendChild(div2)
    }
}