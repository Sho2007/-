<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <h2><a href="index.php">Smarthphone</a></h2>
  <p>Select brand:</p>
  <div class="btn-group">
    <a href="?brand=Apple" type="button" class="btn btn-primary">Apple</a> // สร้างปุ่ม เมื่อกดปุ่ม urlจะเป็น https://code.php/?brand=Apple  
    <a href="?brand=Samsung" type="button" class="btn btn-primary">Samsung</a> // สร้างปุ่ม เมื่อกดปุ่ม urlจะเป็น https://code.php/?brand=Samsung
    <a href="?brand=Huawei" type="button" class="btn btn-primary">Huawei</a> // สร้างปุ่ม เมื่อกดปุ่ม urlจะเป็น https://code.php/?brand=Huawei
    <a href="?brand=OPPO" type="button" class="btn btn-primary">OPPO</a> // สร้างปุ่ม เมื่อกดปุ่ม urlจะเป็น https://code.php/?brand=OPPO
  </div>
</div>
<div class="container mt-3">
  <?php
     $json_txt = file_get_contents("smartphone.json"); //importไฟล์ข้อมูลjson
     $products = json_decode($json_txt,true); // แปลงรูปภาษาjsonให้อยู่ในรูปแบบที่phpอ่านได้
     for($i=0;$i<count($products);$i++){ // ทำการลูปสำหรับแสดงผลตามจำนวนของข้อมูล
      $smartphone = $products[$i]; //สร้างตัวแปรสำหรับระบุตำแหน่งแบบArray
      if(isset($_GET["brand"])){ // ถ้าตัว url มีการกำหนดvalue จะถูกส่งไปกระบวนการต่อไป
        if($_GET["brand"] == $smartphone["brand"]){ // หาตัวค่าvalueของurlที่ตรงกับข้อมูลjson ถ้าตรงก็จะถูกแสดงผลทันที
          echo $smartphone["title"];echo "<br/>";
          $img=$smartphone["thumbnail"];
          echo "<img src ='$img'>";
          echo "<br/>";
      }}
      }
     //json_encode($json_txt);    <---- อย่าพึ่งสนใจ
     //file_put_contents("");     <---- อย่าพึ่งสนใจ
  ?>
</div>
</body>
</html>
