
fetch('box.json')

    .then(function (response) {
        return response.json()
    })
    .then(function (data) {
        appendData(data)
    })
    .catch(function (err) {
        console.log('error: ' + err)
    })

function appendData(data) {
    
    var mainContainer = document.getElementById("data-json");
    // upper this code is container for put
    // inner in it (appendChild)
    for (var i = 0;i < data.length; i++) {
        var div = document.createElement("div");
        var picture = document.createElement("img");
        
        div.innerHTML = "Name: " + data[i].firstname + " " + data[i].lastname;
        picture.innerHTML = "Images" + data[i].images;
        mainContainer.appendChild(div);
        mainContainer.appendChild(picture);

        
    }
}
