<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

    <?php
        $json_text = file_get_contents("Store.json");
        $products = json_decode($json_text,true);

        echo number_format($products[0]["cost"]);
        
        for ($i=0;$i<count($products);$i++){
            if(isset($_GET["brand"])) {
                if ($_GET["brand"] == $products[$i]["category"]) {
                    echo "<img src='" . $products[$i]["name"] . "'>";
                }
            }
        }
    ?>
</body>
</html>